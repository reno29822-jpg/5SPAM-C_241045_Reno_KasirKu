package com.dipa.kasirku
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class DashboardActivity : Activity() {

    private lateinit var tvNamaPengguna: TextView
    private lateinit var btnKategori: Button
    private lateinit var btnProduk: Button
    private lateinit var btnTransaksi: Button
    private lateinit var btnRiwayat: Button
    private lateinit var btnLogout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Menghubungkan komponen XML
        tvNamaPengguna = findViewById(R.id.tvNamaPengguna)
        btnKategori = findViewById(R.id.btnKategori)
        btnProduk = findViewById(R.id.btnProduk)
        btnTransaksi = findViewById(R.id.btnTransaksi)
        btnRiwayat = findViewById(R.id.btnRiwayat)
        btnLogout = findViewById(R.id.btnLogout)

        // Mengambil nama pengguna dari SharedPreferences
        val session = getSharedPreferences(
            "KasirKuSession",
            MODE_PRIVATE
        )

        val nama = session.getString("nama", "Pengguna")
        tvNamaPengguna.text = nama

        // Tombol menu sementara
        btnKategori.setOnClickListener {
            Toast.makeText(this, "Menu Kategori", Toast.LENGTH_SHORT).show()
        }

        btnProduk.setOnClickListener {
            Toast.makeText(this, "Menu Produk", Toast.LENGTH_SHORT).show()
        }

        btnTransaksi.setOnClickListener {
            Toast.makeText(this, "Menu Transaksi", Toast.LENGTH_SHORT).show()
        }

        btnRiwayat.setOnClickListener {
            Toast.makeText(this, "Menu Riwayat Transaksi", Toast.LENGTH_SHORT).show()
        }

        // Tombol Logout
        btnLogout.setOnClickListener {
            session.edit().clear().apply()

            Toast.makeText(
                this,
                "Berhasil logout",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
            finish()
        }
    }
}
