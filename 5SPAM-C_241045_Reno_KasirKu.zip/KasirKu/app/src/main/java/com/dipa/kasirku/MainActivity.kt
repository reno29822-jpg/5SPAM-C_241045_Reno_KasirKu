
package com.dipa.kasirku

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest

class MainActivity : Activity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        preferences = getSharedPreferences(
            "KasirKuSession",
            MODE_PRIVATE
        )

        val etUsername = findViewById<EditText>(
            R.id.etUsernameLogin
        )

        val etPassword = findViewById<EditText>(
            R.id.etPasswordLogin
        )

        val btnLogin = findViewById<Button>(
            R.id.btnLogin
        )

        val btnRegister = findViewById<Button>(
            R.id.btnKeRegister
        )

        // Tombol Login
        btnLogin.setOnClickListener {

            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    this,
                    "Username dan password wajib diisi!",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val passwordHash = hashPassword(password)

            val db: SQLiteDatabase = dbHelper.readableDatabase

            val cursor = db.rawQuery(
                "SELECT id_user, nama, username FROM users " +
                        "WHERE username = ? AND password_hash = ?",
                arrayOf(username, passwordHash)
            )

            if (cursor.moveToFirst()) {

                val idUser = cursor.getInt(0)
                val nama = cursor.getString(1)
                val usernameDB = cursor.getString(2)

                // Menyimpan status login
                preferences.edit()
                    .putBoolean("isLoggedIn", true)
                    .putInt("id_user", idUser)
                    .putString("nama", nama)
                    .putString("username", usernameDB)
                    .apply()

                Toast.makeText(
                    this,
                    "Login berhasil!",
                    Toast.LENGTH_SHORT
                ).show()

                // Membuka Dashboard
                val intent = Intent(
                    this,
                    DashboardActivity::class.java
                )

                startActivity(intent)
                finish()

            } else {

                Toast.makeText(
                    this,
                    "Login gagal! Username atau password salah.",
                    Toast.LENGTH_LONG
                ).show()
            }

            cursor.close()
        }

        // Tombol Registrasi
        btnRegister.setOnClickListener {

            val intent = Intent(
                this,
                RegisterActivity::class.java
            )

            startActivity(intent)
        }
    }

    // Hash password SHA-256
    private fun hashPassword(password: String): String {

        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(password.toByteArray(Charsets.UTF_8))

        return bytes.joinToString("") {
            "%02x".format(it)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        dbHelper.close()
    }
}
