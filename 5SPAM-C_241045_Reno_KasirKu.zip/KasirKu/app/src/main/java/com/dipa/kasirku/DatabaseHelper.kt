package com.dipa.kasirku

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "kasirku.db"
        private const val DATABASE_VERSION = 1

        // Tabel users
        const val TABLE_USERS = "users"

        // Tabel kategori
        const val TABLE_KATEGORI = "kategori"

        // Tabel produk
        const val TABLE_PRODUK = "produk"

        // Tabel transaksi
        const val TABLE_TRANSAKSI = "transaksi"

        // Tabel detail transaksi
        const val TABLE_DETAIL = "detail_transaksi"
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {

        // 1. Tabel users
        db.execSQL("""
            CREATE TABLE $TABLE_USERS (
                id_user INTEGER PRIMARY KEY AUTOINCREMENT,
                nama TEXT NOT NULL,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """.trimIndent())

        // 2. Tabel kategori
        db.execSQL("""
            CREATE TABLE $TABLE_KATEGORI (
                id_kategori INTEGER PRIMARY KEY AUTOINCREMENT,
                nama_kategori TEXT NOT NULL UNIQUE,
                deskripsi TEXT
            )
        """.trimIndent())

        // 3. Tabel produk
        db.execSQL("""
            CREATE TABLE $TABLE_PRODUK (
                id_produk INTEGER PRIMARY KEY AUTOINCREMENT,
                nama_produk TEXT NOT NULL,
                harga REAL NOT NULL CHECK(harga >= 0),
                stok INTEGER NOT NULL CHECK(stok >= 0),
                id_kategori INTEGER NOT NULL,
                FOREIGN KEY (id_kategori)
                    REFERENCES $TABLE_KATEGORI(id_kategori)
                    ON UPDATE CASCADE
                    ON DELETE RESTRICT
            )
        """.trimIndent())

        // 4. Tabel transaksi
        db.execSQL("""
            CREATE TABLE $TABLE_TRANSAKSI (
                id_transaksi INTEGER PRIMARY KEY AUTOINCREMENT,
                id_user INTEGER NOT NULL,
                tanggal TEXT DEFAULT CURRENT_TIMESTAMP,
                total REAL NOT NULL DEFAULT 0,
                FOREIGN KEY (id_user)
                    REFERENCES $TABLE_USERS(id_user)
                    ON UPDATE CASCADE
                    ON DELETE RESTRICT
            )
        """.trimIndent())

        // 5. Tabel detail transaksi
        db.execSQL("""
            CREATE TABLE $TABLE_DETAIL (
                id_detail INTEGER PRIMARY KEY AUTOINCREMENT,
                id_transaksi INTEGER NOT NULL,
                id_produk INTEGER NOT NULL,
                jumlah INTEGER NOT NULL CHECK(jumlah > 0),
                harga REAL NOT NULL CHECK(harga >= 0),
                subtotal REAL NOT NULL CHECK(subtotal >= 0),

                FOREIGN KEY (id_transaksi)
                    REFERENCES $TABLE_TRANSAKSI(id_transaksi)
                    ON UPDATE CASCADE
                    ON DELETE CASCADE,

                FOREIGN KEY (id_produk)
                    REFERENCES $TABLE_PRODUK(id_produk)
                    ON UPDATE CASCADE
                    ON DELETE RESTRICT
            )
        """.trimIndent())
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_DETAIL")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TRANSAKSI")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUK")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_KATEGORI")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")

        onCreate(db)
    }
}
