package com.dipa.kasirku

import android.app.Activity
import android.os.Bundle
import android.content.ContentValues
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest

class RegisterActivity : Activity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        dbHelper = DatabaseHelper(this)

        val etNama = findViewById<EditText>(R.id.etNama)
        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etKonfirmasi = findViewById<EditText>(
            R.id.etKonfirmasiPassword
        )

        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val btnKembali = findViewById<Button>(R.id.btnKembaliLogin)

        btnRegister.setOnClickListener {

            val nama = etNama.text.toString().trim()
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString()
            val konfirmasi = etKonfirmasi.text.toString()

            // Validasi input kosong
            if (nama.isEmpty() || username.isEmpty() ||
                password.isEmpty() || konfirmasi.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Semua kolom wajib diisi!",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Validasi panjang password
            if (password.length < 6) {
                Toast.makeText(
                    this,
                    "Password minimal 6 karakter!",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Validasi konfirmasi password
            if (password != konfirmasi) {
                Toast.makeText(
                    this,
                    "Konfirmasi password tidak cocok!",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Mengubah password menjadi hash
            val passwordHash = hashPassword(password)

            // Menyimpan data ke SQLite
            val db = dbHelper.writableDatabase

            val values = ContentValues().apply {
                put("nama", nama)
                put("username", username)
                put("password_hash", passwordHash)
            }

            val result = db.insert(
                DatabaseHelper.TABLE_USERS,
                null,
                values
            )

            if (result != -1L) {

                Toast.makeText(
                    this,
                    "Registrasi berhasil! Silakan login.",
                    Toast.LENGTH_LONG
                ).show()

                finish()

            } else {

                Toast.makeText(
                    this,
                    "Registrasi gagal! Username mungkin sudah digunakan.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        // Kembali ke halaman sebelumnya
        btnKembali.setOnClickListener {
            finish()
        }
    }

    // Fungsi hash SHA-256
    private fun hashPassword(password: String): String {

        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(password.toByteArray(Charsets.UTF_8))

        return bytes.joinToString("") {
            "%02x".format(it)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        dbHelper.close()
    }
}
